#!/usr/bin/env python
# coding: utf-8

# In[72]:


#import packages
import pandas as pd
from mpl_toolkits import mplot3d
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.cluster import SpectralClustering
import time
import seaborn as sns
from pandas import Series, DataFrame
get_ipython().run_line_magic('matplotlib', 'inline')
import warnings
warnings.filterwarnings('ignore')


# In[73]:


data=pd.read_csv('Customers-1.csv') #Reading the CSV %%file


# In[78]:


data #Data Layout


# In[74]:


data.info() #Information of the Data


# In[75]:


data.columns #Columns of the data


# In[76]:


#data.drop(["CustomerID"], axis = 1, inplace=True)


# In[77]:


# syntax for 3-D projection
ax = plt.axes(projection ='3d')
ax.scatter3D(data["Age"], data["AnnualIncome"], data["SpendingScore"],'blue')
plt.xlabel("Age")
plt.ylabel("Annual Income")
ax.set_zlabel('Spending Score')
plt.show()


# In[47]:


X=data.iloc[:, [2,3,4]].values
X #Test data 


# In[80]:


k_list=[]
inertia_list=[]
for k in range(1,10):
    model = KMeans(n_clusters=k, init="k-means++", random_state=0)
    label = model.fit_predict(X)
    inertia = model.inertia_
    inertia_list.append(inertia)
    k_list.append(k)


# In[81]:


k_list 


# In[82]:


inertia


# In[84]:


inertia_list


# In[49]:


plt.figure(figsize= (15,8))
plt.plot(k_list,inertia_list,linewidth=2,marker='8')
plt.title("Elbow Method")
plt.xlabel('K')
plt.ylabel('Inertia')
plt.show()


# In[50]:


max_sl = 0
best_k = 1
for k in range(1,10):  
    if (k == 1):
        continue
    model = KMeans(n_clusters=k, init="k-means++", random_state=0)
    label = model.fit_predict(X)
    inertia = model.inertia_
    sl=silhouette_score(X,label)
    if(max_sl < sl):
        max_sl = sl
        best_k = k
    print("the silhoutte score for k=",k)
    print("is  ",sl)
print("The best value of k is " + str(best_k) + " with sl " + str(max_sl))


# In[52]:


X=data.iloc[:, [2,4]].values
X


# In[53]:


k_list=[]
inertia_list=[]
for k in range(1,10):
    model = KMeans(n_clusters=k, init="k-means++", random_state=0)
    label = model.fit_predict(X)
    inertia = model.inertia_
    inertia_list.append(inertia)
    k_list.append(k)


# In[54]:


plt.figure(figsize= (15,8))
plt.plot(k_list,inertia_list,linewidth=2,marker='8')
plt.title("Elbow Method")
plt.xlabel('K')
plt.ylabel('Inertia')
plt.show()


# In[55]:


max_sl = 0
best_k = 1
for k in range(1,10):  
    if (k == 1):
        continue
    model = KMeans(n_clusters=k, init="k-means++", random_state=0)
    label = model.fit_predict(X)
    inertia = model.inertia_
    sl=silhouette_score(X,label)
    if(max_sl < sl):
        max_sl = sl
        best_k = k
    print("the silhoutte score for k=",k)
    print("is  ",sl)
print("The best value of k is " + str(best_k) + " with sl " + str(max_sl))


# In[56]:


kmeans = KMeans(n_clusters=4, init ='k-means++',random_state=0 )
y_kmeans = kmeans.fit_predict(X)


# In[57]:


plt.scatter(X[y_kmeans==0, 0], X[y_kmeans==0, 1], s=100, c='yellow', label ='Cluster 1')
plt.scatter(X[y_kmeans==1, 0], X[y_kmeans==1, 1], s=100, c='blue', label ='Cluster 2')
plt.scatter(X[y_kmeans==2, 0], X[y_kmeans==2, 1], s=100, c='green', label ='Cluster 3')
plt.scatter(X[y_kmeans==3, 0], X[y_kmeans==3, 1], s=100, c='cyan', label ='Cluster 4')
plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s=300, c='red', label = 'Centroids')
plt.title('Clusters of Age and Spending Score')
plt.xlabel('Age')
plt.ylabel('Spending Score')
plt.show()


# In[59]:


X=data.iloc[:, [2,3]].values
X


# In[60]:


k_list=[]
inertia_list=[]
for k in range(1,10):
    model = KMeans(n_clusters=k, init="k-means++", random_state=0)
    label = model.fit_predict(X)
    inertia = model.inertia_
    inertia_list.append(inertia)
    k_list.append(k)


# In[61]:


plt.figure(figsize= (15,8))
plt.plot(k_list,inertia_list,linewidth=2,marker='8')
plt.title("Elbow Method")
plt.xlabel('K')
plt.ylabel('Inertia')
plt.show()


# In[62]:


max_sl = 0
best_k = 1
for k in range(1,10):  
    if (k == 1):
        continue
    model = KMeans(n_clusters=k, init="k-means++", random_state=0)
    label = model.fit_predict(X)
    inertia = model.inertia_
    sl=silhouette_score(X,label)
    if(max_sl < sl):
        max_sl = sl
        best_k = k
    print("the silhoutte score for k=",k)
    print("is  ",sl)
print("The best value of k is " + str(best_k) + " with sl " + str(max_sl))


# In[63]:


kmeans = KMeans(n_clusters=4, init ='k-means++',random_state=0 )
y_kmeans = kmeans.fit_predict(X)


# In[64]:



plt.scatter(X[y_kmeans==0, 0], X[y_kmeans==0, 1], s=100, c='yellow', label ='Cluster 1')
plt.scatter(X[y_kmeans==1, 0], X[y_kmeans==1, 1], s=100, c='blue', label ='Cluster 2')
plt.scatter(X[y_kmeans==2, 0], X[y_kmeans==2, 1], s=100, c='green', label ='Cluster 3')
plt.scatter(X[y_kmeans==3, 0], X[y_kmeans==3, 1], s=100, c='cyan', label ='Cluster 4')
plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s=300, c='red', label = 'Centroids')
plt.title('Clusters of Age and Annual Income')
plt.xlabel('Age')
plt.ylabel('Annual Income')
plt.show()


# In[66]:


X=data.iloc[:, [4,3]].values
X


# In[67]:


k_list=[]
inertia_list=[]
for k in range(1,10):
    model = KMeans(n_clusters=k, init="k-means++", random_state=0)
    label = model.fit_predict(X)
    inertia = model.inertia_
    inertia_list.append(inertia)
    k_list.append(k)


# In[68]:


plt.figure(figsize= (15,8))
plt.plot(k_list,inertia_list,linewidth=2,marker='8')
plt.title("Elbow Method")
plt.xlabel('K')
plt.ylabel('Inertia')
plt.show()


# In[69]:


max_sl = 0
best_k = 1
for k in range(1,10):  
    if (k == 1):
        continue
    model = KMeans(n_clusters=k, init="k-means++", random_state=0)
    label = model.fit_predict(X)
    inertia = model.inertia_
    sl=silhouette_score(X,label)
    if(max_sl < sl):
        max_sl = sl
        best_k = k
    print("the silhoutte score for k=",k)
    print("is  ",sl)
print("The best value of k is " + str(best_k) + " with sl " + str(max_sl))


# In[89]:


kmeans = KMeans(n_clusters=6, init ='k-means++',random_state=0 )
y_kmeans = kmeans.fit_predict(X)


# In[91]:


plt.scatter(X[y_kmeans==0, 0], X[y_kmeans==0, 1], s=100, c='yellow', label ='Cluster 1')
plt.scatter(X[y_kmeans==1, 0], X[y_kmeans==1, 1], s=100, c='blue', label ='Cluster 2')
plt.scatter(X[y_kmeans==2, 0], X[y_kmeans==2, 1], s=100, c='green', label ='Cluster 3')
plt.scatter(X[y_kmeans==3, 0], X[y_kmeans==3, 1], s=100, c='cyan', label ='Cluster 4')
plt.scatter(X[y_kmeans==4, 0], X[y_kmeans==4, 1], s=100, c='purple', label ='Cluster 5')
plt.scatter(X[y_kmeans==5, 0], X[y_kmeans==5, 1], s=100, c='purple', label ='Cluster 6')
plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s=300, c='red', label = 'Centroids')
plt.title('Spending Score and Annual Income')
plt.xlabel('Spending Score')
plt.ylabel('Annual Income')
plt.show()


# In[ ]:





# In[ ]:




